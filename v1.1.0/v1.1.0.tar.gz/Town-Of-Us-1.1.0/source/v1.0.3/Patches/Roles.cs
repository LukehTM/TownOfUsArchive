namespace TownOfUs
{
    public enum Roles
    {
        Sheriff,
        Jester,
        Engineer,
        Lover1,
        Lover2,
        Mayor,
        Swapper,
        Investigator,
        TimeMaster,
        Crewmate,
        Impostor,
        None,
    }
}
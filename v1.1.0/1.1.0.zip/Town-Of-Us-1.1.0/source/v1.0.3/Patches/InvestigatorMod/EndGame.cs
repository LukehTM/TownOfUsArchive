namespace TownOfUs.InvestigatorMod
{
    public class EndGame
    {
        
    }
}
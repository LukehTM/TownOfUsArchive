namespace TownOfUs
{
    public enum Faction
    {
        Crewmates,
        Impostors,
        Neutral,
    }
}
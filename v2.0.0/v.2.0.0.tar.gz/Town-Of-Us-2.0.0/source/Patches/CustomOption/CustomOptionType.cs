namespace TownOfUs.CustomOption
{
    public enum CustomOptionType
    {
        Header,
        Toggle,
        Number,
        String,
        Button,
    }
}
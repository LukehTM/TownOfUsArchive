namespace TownOfUs.SeerMod
{
    public enum SeerInfo
    {
        Role = 0,
        Faction,
    }

    public enum SeeReveal
    {
        Crew = 0,
        ImpsAndNeut,
        All,
        Nobody,
    }
}
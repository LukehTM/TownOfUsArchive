namespace TownOfUs
{
    public enum MurderEnum
    {
        Normal,
        Sheriff,
        Shifter,
        Lover,
        Glitch,
    }
}
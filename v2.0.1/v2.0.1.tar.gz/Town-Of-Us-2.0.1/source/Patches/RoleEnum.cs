namespace TownOfUs
{
    public enum RoleEnum
    {
        Sheriff,
        Jester,
        Engineer,
        LoverImpostor,
        Lover,
        Mayor,
        Swapper,
        Investigator,
        TimeLord,
        Shifter,
        Medic,
        Seer,
        Executioner,
        Child,
        Spy,
        Snitch,
        Arsonist,
        Altruist,

        Miner,
        Swooper,
        Morphling,
        Camouflager,
        Janitor,

        Glitch,
        
        Crewmate,
        Impostor,
        None,
    }

    public enum ModifierEnum
    {
        Torch,
        Diseased,
        Flash,
        Tiebreaker,
        Drunk,
        BigBoi,
        ButtonBarry,
    }
}